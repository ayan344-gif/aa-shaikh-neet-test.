AA Shaikh NEET Test — PDF to MCQ (v7)

HOW TO OPEN
1. Extract this ZIP file.
2. Open index.html in Chrome or another modern browser with internet access.
3. Upload a text-based PDF, select subject, and click “Extract PDF & generate draft MCQs”.
4. Review and correct every draft question, options, answer, and explanation. Add Gujarati translations in the translation fields as needed.
5. Click Start test and select a duration up to 180 minutes.

IMPORTANT LIMITATIONS
- PDF text extraction uses PDF.js from a public CDN, so internet access is needed.
- The included generator uses simple text patterns and fill-in-the-blank heuristics. It is not an AI model and may create weak or incorrect drafts. Please review all questions and answers before using them.
- Gujarati translation fields are included, but this version does not automatically translate English questions into Gujarati.
- Scanned/image-only PDFs require OCR, which is not included.
- Files are processed in the browser; this app does not upload the PDF to a server.
- This is a browser app, not an Android APK and not a public website URL. To make a public URL, host these files on a website service such as GitHub Pages.
